package eu.eventsotrm.core.apt.model;

import javax.lang.model.element.Element;

public interface Descriptor {

	 Element element();
	 
}
