package eu.eventsotrm.core.apt.model;

import java.util.List;

import javax.lang.model.element.Element;

import eu.eventstorm.annotation.CqrsQueryElsIndice;

/**
 * @author <a href="mailto:jacques.militello@gmail.com">Jacques Militello</a>
 */
public final class ElsQueryDescriptor extends QueryDescriptor {

	public ElsQueryDescriptor(Element element, List<QueryPropertyDescriptor> properties) {
		super(element, properties);
	}
	
	public CqrsQueryElsIndice indice() {
		return element().getAnnotation(CqrsQueryElsIndice.class);
	}

}
