package eu.eventsotrm.core.apt;

import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic.Kind;
/*
 * @author <a href="mailto:jacques.militello@gmail.com">Jacques Militello</a>
 */
@SupportedSourceVersion(SourceVersion.RELEASE_8)
@SupportedAnnotationTypes({ "eu.eventstorm.annotation.CqrsCommand","eu.eventstorm.annotation.CqrsQueryElsIndice"})
public class EventProcessor extends AbstractProcessor {

    private boolean firstTime = false;

	@Override
	public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
		
		this.processingEnv.getMessager().printMessage(Kind.NOTE, "***********************************");
		this.processingEnv.getMessager().printMessage(Kind.NOTE, "***********************************");
		this.processingEnv.getMessager().printMessage(Kind.NOTE, "***********************************");
		this.processingEnv.getMessager().printMessage(Kind.OTHER, "***********************************");
		this.processingEnv.getMessager().printMessage(Kind.WARNING, "***********************************");
		this.processingEnv.getMessager().printMessage(Kind.MANDATORY_WARNING, "***********************************");
		this.processingEnv.getMessager().printMessage(Kind.ERROR, "***********************************");
		
		
		
		return true;
	}

}